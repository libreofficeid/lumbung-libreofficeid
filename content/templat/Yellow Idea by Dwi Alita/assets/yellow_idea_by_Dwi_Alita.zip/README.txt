This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License by Ermin D. Alita. 
To view a copy of this license, visit https://creativecommons.org/licenses/by-sa/4.0/legalcode or send a letter to Creative Commons,
PO Box 1866, Mountain View, CA 94042, USA.

And also this work is using :
1. Open Sans Condensed Font wich this fonts are licensed under the Apache License, Version 2.0.
You can view this license on http://www.apache.org/licenses/LICENSE-2.0 or/and get this font on https://fonts.google.com/specimen/Open+Sans+Condensed
2. Ubuntu Font wich this fonts are licensed under the Ubuntu font licence, Version 1.0.
You can view this license on https://ubuntu.com/legal/font-licence or/and get this font on https://design.ubuntu.com/font/

For the best result please make sure the mentioned fonts are already installed on your system.
