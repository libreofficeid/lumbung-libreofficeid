               Grey Elegant - Libre Office Impress Template

This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 
International License by Ahmad Bayhaqi Saputra <bayhaqisptr04@gmail.com>. 
To view a copy of this license, visit https://creativecommons.org/licenses/by-sa/4.0/legalcode 
or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

To best result please make sure Lato font are already installed on your machine

Content Material : 

- icons,
  This template used icons from https://material.io and https://icons8.com/icons
- illustrations,
  This template used illustrations sourced at https://icons8.com/illustrations
- Photos,
  This template used photos sourced at https://unsplash.com
- Font,
  This template recommended using Lato Font from https://fonts.google.com/specimen/Lato 
  that use Open Font License


