#Freshes LOImpress Template <br /><small>by Risyad Rais</small>

Freshes LOImpress Template is supposed to be a template for LibreOffice 
Impress. But I guess calling it a placeholder or sample slides might be even 
more suitable since it's not really optimized properly for LibreOffice Impress 
Workflow.

This template is made as an answer to Indonesian LibreOffice Community and
Gimpscape ID's call-to-arms to contribute to the 10th anniversary of
LibreOffice celebration.


##How to:
It's recommended to install Lato font family for this template.

###Normal slides:
1. Duplicate the slide you want to edit
2. Edit the texts
3. Rearrange the slides and remove the ones you don't need

###Icons:
To change icons, go to: ``Insert -> Special Character`` and choose the one you
like.

###Chart slides:
1. Double click the chart
2. Edit Data Table


##Features
1. A fresh looking first and last slide with huge typography
2. Covered single bullet to four bullets slides
3. Charts available in three styles: Pie, Collumns, and Line
4. A very mediocre looking Diagram and Table slide
5. Timeline slides
6. Super simple Closing slide


If you tried this and have any suggestions, feel free to send a mail: satmo54[at]gmail[dot]com


##Acknowledgements
Here's some resources I used to make this template:

###Images:
Images used here are licensed uner [Unsplash License](https://unsplash.com/license).

1. [White clouds and blue skies](https://unsplash.com/photos/DbwYNr8RPbg) by Resul on Unsplash.
2. [Four on flight hot air balloons](https://unsplash.com/photos/HcuKlhq4osM) by C.Valdez on Unsplash.

###Fonts:
1. Lato & Lato Black, licensed under
[Open Font License](https://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL)
2. Font Awesome Free v4 ([license](https://fontawesome.com/license/free))


##License
This template is released under CC by SA 4.0 License. Other resources used in
this template have their own respective licenses you might want to check.
