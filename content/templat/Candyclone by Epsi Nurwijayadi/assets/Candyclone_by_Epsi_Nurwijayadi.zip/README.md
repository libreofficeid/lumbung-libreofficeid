# Impress Template: Candyclone

Classic modern template based on the looks of Hervy's works.
I rewrite all master slides using inkscape.

> Four kind of master slides with 19 material colors.
> The result is 76 master slides.

![Template: Candyclone][template-candy]

-- -- --

## Specification

### Slides Ratio

> 16:9

### Font

I use two fonts for this template:

1. Source San Pro

2. Source San Pro Semibold

#### Color

I use Google Material.
Google Material Pallete has 19 distinct color type.

### Master Slide

> 4 * 19

There are only four kinds of master slides:

* Default

* Chapter: For chapter title or chapter break

* Single: To show Figures, Chart or Infographics

* Background: Inverted version of default, using background

Each four kind of master slides implemented with 19 google colors.
Resulting total of 76 master slides.

-- -- --

## Credits: Hervy QA

> Kudos to his excellent works!

Inspired by Hervy QA.
Without his examples, I could never make this `candyclone` template.

This template is a total rewrite based on design made by Hervy QA. 
Pages per pages, following the original design. 
With Permission from Hervy QA.

You can find the original template here.

* [Gnome Bluez Libreoffice Impress Free Template][hervy-qa-bluez]

Enjoy his videos too.

* [Demo GNOME Bluez Libre Office Impress Free Template][hervy-qa-video]

-- -- --

## Tutorial

* [Inkscape: Impress Slides - Part Two][impress-slides-2]

-- -- --

## Inkscape: Decoration Artwork Source

> Original Decoration

### Bullets

* [Inkscape: Progress Ring Animation][progress-ring]

### Isometric Wallpapers

* [Isometric Wallpaper][isometric-wall]

### Business Cards

* [Inkscape - Kartu Nama][kartu-nama]

### Cubes

* [Inkscape: Isometric Infographics][isometric-cubes]

-- -- --

## Inkscape: Content Artwork Source

> Make this Template Usable

Soon

[template-candy]:   https://github.com/epsi-rns/berkas2/raw/master/impress-template-candyclone/preview/template-candyclone-cover.png
[impress-slides-2]: https://epsi-rns.gitlab.io/design/2020/09/22/inkscape-impress-slides-02/
[hervy-qa-bluez]:   https://hervyqa.com/gnome-bluez-libreoffice-impress-free-template/
[hervy-qa-video]:   http://www.youtube.com/watch?v=O3urHT5AHG8

[isometric-wall]:   https://github.com/epsi-rns/isometric-wallpaper
[kartu-nama]:       https://akutidaktahu.netlify.app/inkscape/2017/10/03/kartu-nama.html
[isometric-cubes]:  https://epsi-rns.gitlab.io/design/2015/11/11/inkscape-isometric-infographics/
[progress-ring]:    https://epsi-rns.gitlab.io/design/2017/11/15/inkscape-progress-ring/
