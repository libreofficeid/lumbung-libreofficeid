This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License by Rania Amina. All embeded images credited to the creators.
To view a copy of this license, visit https://creativecommons.org/licenses/by-sa/4.0/legalcode or send a letter to Creative Commons,
PO Box 1866, Mountain View, CA 94042, USA.

And also this work is using Poppins Font wich this fonts are licensed under the Open Fonts License (OFL).
You can get this font on https://fonts.google.com/specimen/Poppins.
For the best result please make sure the mentioned font are already installed.
